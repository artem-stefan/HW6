import UIKit

/* Создайте два массива. Первый от 0 до 14, второй от 14 до 30. Объедините их в один
 массив. */

let firstArray = Array(0...14)
let secondArray = Array(14...30)
let combinedArray = firstArray + secondArray

print(combinedArray)

/*Создать функцию, которая принимает массив int. Возвести все Int в квадрат.
 Возвратить новый массив.*/

func squareElements (in array: [Int]) -> [Int] {
    return array.map { $0 * $0 }
}
let squaredArray = squareElements(in: combinedArray)
print(squaredArray)

/* Создать функцию, которая принимает массив int. Возвратить новый массив с только
 четными элементами.*/

func evenElements (in array: [Int]) -> [Int] {
    return array.filter{$0 % 2 == 0}
}
let evenArray = evenElements(in: combinedArray)
print(evenArray)

/*
 Написать 3 примера с использованием .map
 */
let mapDoubled = combinedArray.map { $0 * 2 }
print(mapDoubled)
let mapTriple = combinedArray.map { $0 + 3 }
print(mapTriple)

/*
 Написать 2 примера с использованием .filter
 */

let filterEvens = combinedArray.filter { $0 % 2 == 0 }
print(filterEvens)
let filterGreaterThan20 = combinedArray.filter { $0 > 20 }
print(filterGreaterThan20)

/*
 Написать 2 примера с использованием .compactMap
 */

/*
 Написать 2 примера с .sort
 */
var sortableArray = combinedArray
sortableArray.sort()
print(sortableArray)


/*
 Написать 2 примера с .sorted
 */
let sortedArrayAsc = combinedArray.sorted()
print(sortedArrayAsc) 
